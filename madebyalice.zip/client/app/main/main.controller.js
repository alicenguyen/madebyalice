'use strict';

angular.module('madebyaliceApp')
  .controller('MainCtrl', function ($scope) {
    $scope.awesomeThings = [];
  });
