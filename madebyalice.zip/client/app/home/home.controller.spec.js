'use strict';

describe('Controller: HomeCtrl', function () {


});
